# 예측 기준 분봉
TARGET_INTERVAL = "30m"

# 나스닥 시장 지수
INDEX_SYMBOL = "^IXIC"

# 데이터 수집 기간
START_DATE = "2025-04-20"
END_DATE = "2025-05-21"
INTERVALS = ["5m", "15m", "30m", "60m", "1d"]

MARKET_MODEL_PATH = "models/market/lstm_market.pt"

# 학습 대상 종목 리스트
SYMBOL_LIST = [
    "AAPL", "MSFT", "NVDA"] #, "AMZN", "GOOGL", "GOOG", "META", "TSLA", "BRK.B", "UNH"]
    
'''
    ,
    "JNJ",  "V",    "XOM",  "JPM",  "MA",    "PG",   "LLY",  "HD",   "CVX",  "ABBV",
    "PEP",  "KO",   "MRK",  "AVGO", "BAC",   "COST", "WMT",  "DIS",  "ADBE", "CSCO",
    "PFE",  "CMCSA","TMO",  "ABT",  "ACN",   "DHR",  "MCD",  "INTC", "CRM",  "LIN",
    "VZ",   "NEE",  "TXN",  "NKE",  "MDT",   "AMGN", "HON",  "UNP",  "ORCL", "BMY",
    "QCOM", "LOW",  "UPS",  "INTU", "PM",    "IBM",  "MS",   "RTX",  "CAT",  "GS",
    "AMAT", "NOW",  "BLK",  "SPGI", "ISRG",  "DE",   "T",    "GE",   "LRCX", "PLD",
    "MDLZ", "SCHW", "AXP",  "CI",   "ADI",   "ZTS",  "SYK",  "CB",   "MMC",  "MO",
    "GILD", "BKNG", "ADI",  "DUK",  "SO",    "ADP",  "VRTX", "USB",  "REGN", "BDX",
    "C",    "CSX",  "TGT",  "PNC",  "FIS",   "ETN",  "EQIX", "CL",   "ITW",  "TFC",
    "NSC",  "GM",   "ECL",  "EL",   "EMR",   "WM",   "AON",  "APD",  "FDX",  "PSA",
    "COF",  "AIG",  "D",    "HUM",  "MCO",   "ICE",  "PSX",  "AEP",  "SHW",  "MET",
    "MAR",  "KMB",  "SRE",  "ALL",  "CTSH",  "DG",   "MNST", "TEL",  "F",    "CMI",
    "EXC",  "ROST", "MPC",  "AZO",  "SPG",   "TRV",  "ORLY", "AFL",  "IDXX", "PRU",
    "DLR",  "WELL", "HCA",  "SLB",  "WMB",   "STZ",  "MTD",  "ED",   "DOW",  "HLT",
    "PCAR", "HPQ",  "PAYX", "WEC",  "ANET",  "ROK",  "ODFL", "VLO",  "PH",   "NOC",
    "SYY",  "EOG",  "FTNT", "WST",  "CTAS",  "MSI",  "PGR",  "NUE",  "KMI",  "DLTR",
    "CDNS", "CME",  "TT",   "PXD",  "CHD",   "KEYS", "MLM",  "FISV", "AME",  "RSG",
    "A",    "GPN",  "NEM",  "VRSK", "TSCO",  "OTIS", "CARR", "HIG",  "FAST", "VFC",
    "ALGN", "AVB",  "IQV",  "EFX",  "LHX",   "HPE",  "BAX",  "WBA",  "ZBH",  "KHC",
    "BKR",  "EXR",  "PPG",  "MTB",  "DHI",   "ETSY", "FANG", "NVR",  "RMD",  "MAA",
    "LEN",  "ARE",  "HES",  "LDOS", "EIX",   "STT",  "SIVB", "CFG",  "VTR",  "HBAN",
    "WRB",  "KEY",  "FITB", "RF",   "LUV",   "CNP",  "NI",   "FE",   "CMS",  "AES",
    "PNW",  "DTE",  "ES",   "AEE",  "EVRG",  "ETR",  "PEG",  "WDC",  "IP",   "PKI",
    "LKQ",  "NDAQ", "RHI",  "NTRS", "ZION",  "LNT",  "NRG",  "PPL",  "AIZ",  "CINF",
    "ALLE", "BWA",  "J",    "XYL",  "MAS",   "HII",  "WRK",  "NWSA", "NWS",  "FOX",
    "FOXA", "DISCK","DISCA","DISH", "UA",    "UAA",  "NCLH", "CCL",  "ALK",  "AAL",
    "UAL",  "LNC",  "BEN",  "IVZ",  "AMP",   "TROW", "STX",  "NTAP", "GLW",  "DXC",
    "HP",   "NOV",  "MRO",  "APA",  "FMC",   "MOS",  "CF",   "NWL",  "HAS",  "LEG",
    "WHR",  "RL",   "PVH",  "KSS",  "GPS",   "BBY",  "HRL",  "CPB",  "K",    "SJM",
    "MKC",  "TAP",  "BF.B", "CLX",  "CHRW",  "JBHT", "L",    "HOG",  "NLSN", "SEE",
    "PKG",  "IPG",  "OMC",  "NWSA", "NWS",   "VIAC", "CBS",  "TWTR", "EBAY", "ETSY",
    "GRMN", "TSN",  "KR",   "DGX",  "LH",    "TDG",  "TXT",  "IR",   "EMN",  "BLL",
    "CE",   "ALB",  "CF",   "MOS",  "FMC",   "NUE",  "STLD", "X",    "AA",   "ATI",
    "CMC",  "RS",   "SCHN", "SCCO", "TECK",  "VALE", "WPM",  "AG",   "AU",   "GOLD"
]
'''