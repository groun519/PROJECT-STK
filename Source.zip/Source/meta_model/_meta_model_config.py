# === 설정 ===
META_START = "2025-05-18 09:30"
META_END   = "2025-05-20 16:00"
SYMBOL     = "TSLA"
CACHE_DIR  = "./meta"
os.makedirs(CACHE_DIR, exist_ok=True)

INTERVALS  = ["5m", "15m", "30m", "60m", "1d"]
MODEL_DIR  = "./models"                         # model_5m.pt ...
DEVICE     = "cuda" if torch.cuda.is_available() else "cpu"