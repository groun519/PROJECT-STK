# codeblock: make_meta_dataset.py
import os, joblib, torch, numpy as np, pandas as pd
from datetime import datetime
from tqdm import tqdm
from meta_model._meta_model_config import 
from data._data_config import INTERVALS

# --- 유틸: 분봉별 입력 텐서 생성 (이미 프로젝트에 있는 함수 예시) ---
from Source.data.dataset_utils import build_single_sample  # (interval, symbol, ts) -> torch.Tensor

# --- 모델 로드 ---
models = {}
for tf in INTERVALS:
    models[tf] = torch.jit.load(f"{MODEL_DIR}/model_{tf}.pt").to(DEVICE).eval()

def get_label_30m(ts: pd.Timestamp) -> int:
    """다음 1캔들 종가 대비 상승/하락/보합 라벨 (예시)"""
    # (이미 있는 labeling_utils.get_all_labels() 사용해도 OK)
    df = build_single_sample.get_df("30m", SYMBOL)  # 가격 DataFrame
    pos = df.index.get_indexer([ts], method="nearest")[0]
    if pos + 1 >= len(df):  # 마지막 캔들
        return None
    pct = (df["close"].iloc[pos+1] - df["close"].iloc[pos]) / df["close"].iloc[pos]
    if   pct > 0.003: return 0   # 상승
    elif pct < -0.003: return 2  # 하락
    else:               return 1 # 보합

# --- 예측 루프 ---
ts_range = pd.date_range(META_START, META_END, freq="30min", tz="US/Eastern")
X_meta, y_meta = [], []

for ts in tqdm(ts_range, desc="collecting meta features"):
    feats = []
    skip  = False
    for tf in INTERVALS:
        x = build_single_sample(SYMBOL, tf, ts)            # (1, win, feat)
        if x is None:
            skip = True
            break
        with torch.no_grad():
            prob = models[tf](x.to(DEVICE)).softmax(-1).squeeze().cpu().numpy()
        feats.extend(prob)            # [p↑, p↔, p↓]
    if skip:
        continue
    label = get_label_30m(ts)
    if label is None:
        continue
    X_meta.append(feats)
    y_meta.append(label)

np.savez(f"{CACHE_DIR}/meta_dataset.npz", X=np.array(X_meta, dtype=np.float32),
                                         y=np.array(y_meta,  dtype=np.int64))
print(f"saved {len(y_meta)} samples → {CACHE_DIR}/meta_dataset.npz")
